import sys
import os
import json
import time
import sqlite3
import hashlib
import urllib.parse
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')
if not xbmcvfs.exists(PROFILE_PATH):
    xbmcvfs.mkdirs(PROFILE_PATH)

DB_PATH = os.path.join(PROFILE_PATH, 'ryustream_cache.db')
DEFAULT_TMDB_KEY = "4a4c2835f4cb50a1fdb8cf2d5b16daa7"
RD_CLIENT_ID = "X245A4XAIBGVM"
PM_CLIENT_ID = "888228107"
TRAKT_CLIENT_ID = "N2uItt-lTlCfWS_6U2j7JlH64nFMzP4AN_zvB1i7bX4"
SIMKL_CLIENT_ID = "39e8640b6f1a60aaf60f3f3313475e830517badab8048a4e52ff2d10deb2b9b0"

SESSION = requests.Session()
_retries = Retry(total=3, connect=3, read=3, status=3, status_forcelist=(429, 500, 502, 503, 504), backoff_factor=0.3)
SESSION.mount('https://', HTTPAdapter(pool_maxsize=100, max_retries=_retries))

def get_tmdb_key():
    user_key = ADDON.getSetting('tmdb_apikey').strip()
    return user_key if user_key else DEFAULT_TMDB_KEY

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, data TEXT, expires INTEGER)')
    conn.commit()
    conn.close()

def get_cache(key):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT data, expires FROM cache WHERE key = ?', (key,))
    row = c.fetchone()
    conn.close()
    if row and row[1] > int(time.time()):
        return json.loads(row[0])
    return None

def set_cache(key, data, ttl=86400):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('REPLACE INTO cache (key, data, expires) VALUES (?, ?, ?)', (key, json.dumps(data), int(time.time()) + ttl))
    conn.commit()
    conn.close()

def fetch_tmdb(endpoint, extra_params=None):
    tmdb_key = get_tmdb_key()
    if not tmdb_key:
        return list()
    raw_key = f"tmdb_v300_{endpoint}_{json.dumps(extra_params or dict())}"
    cache_key = hashlib.md5(raw_key.encode()).hexdigest()
    cached = get_cache(cache_key)
    if cached is not None:
        return cached

    params = {'api_key': tmdb_key, 'language': 'en-US'}
    if extra_params:
        params.update(extra_params)

    try:
        url = "https://" + "api." + "themoviedb.org/3/" + endpoint
        res = SESSION.get(url, params=params, timeout=10)
        if res.ok:
            results = res.json().get('results', list())
            if results:
                set_cache(cache_key, results)
            return results
        return list()
    except Exception:
        return list()

def get_imdb_id(tmdb_id, media_type='movie'):
    tmdb_key = get_tmdb_key()
    url = f"https://" + f"api.themoviedb.org/3/{media_type}/{tmdb_id}/external_ids"
    try:
        res = SESSION.get(url, params={'api_key': tmdb_key}, timeout=8).json()
        return res.get('imdb_id', '')
    except Exception:
        return ''
def resolve_debrid_magnet(magnet_uri):
    ad_key = ADDON.getSetting('ad_apikey').strip()
    rd_key = ADDON.getSetting('rd_apikey').strip()
    pm_key = ADDON.getSetting('pm_apikey').strip()
    tb_key = ADDON.getSetting('tb_apikey').strip()

    # 1. AllDebrid Resolver (URL เต็มครบถ้วน)
    if ad_key:
        try:
            u1 = "https://" + "api." + "alldebrid.com" + "/v4/magnet/upload"
            r1 = SESSION.get(u1, params={'agent': 'RyuStream', 'apikey': ad_key, 'magnets[]': magnet_uri}, timeout=12).json()
            mags = r1.get('data', {}).get('magnets', list())
            if mags:
                mag_id = mags[0].get('id')
                u2 = "https://" + "api." + "alldebrid.com" + "/v4/magnet/status"
                r2 = SESSION.get(u2, params={'agent': 'RyuStream', 'apikey': ad_key, 'id': mag_id}, timeout=12).json()
                links = r2.get('data', {}).get('magnets', {}).get('links', list())
                if links:
                    best_link = max(links, key=lambda x: x.get('size', 0)).get('link')
                    u3 = "https://" + "api." + "alldebrid.com" + "/v4/link/unlock"
                    r3 = SESSION.get(u3, params={'agent': 'RyuStream', 'apikey': ad_key, 'link': best_link}, timeout=12).json()
                    stream_url = r3.get('data', {}).get('link')
                    if stream_url:
                        return stream_url
        except Exception as e:
            xbmcgui.Dialog().notification('AllDebrid Error', str(e)[:60], xbmcgui.NOTIFICATION_ERROR, 4000)

    # 2. Real-Debrid Resolver (แก้ไข Path เต็ม + เลือกไฟล์วิดีโอใหญ่สุดอัตโนมัติ)
    if rd_key:
        try:
            headers = {'Authorization': f'Bearer {rd_key}'}
            rd_base = "https://" + "api." + "real-debrid.com" + "/rest/1.0"
            r1 = SESSION.post(f"{rd_base}/torrents/addMagnet", data={'magnet': magnet_uri}, headers=headers, timeout=12).json()
            tid = r1.get('id')
            if not tid:
                err_msg = r1.get('error', 'Invalid Token or Magnet')
                xbmcgui.Dialog().notification('Real-Debrid', str(err_msg) + ' - Trying next Debrid...', xbmcgui.NOTIFICATION_WARNING, 3000)

            # ดึงรายชื่อไฟล์ในทอร์เรนต์เพื่อเลือกเฉพาะไฟล์วิดีโอขนาดใหญ่สุด (ป้องกันไฟล์ซับ/ตัวอย่างติดมา)
            info = SESSION.get(f"{rd_base}/torrents/info/{tid}", headers=headers, timeout=12).json()
            files = info.get('files', list())
            vid_files = [f for f in files if f.get('path', '').lower().endswith(('.mkv', '.mp4', '.avi', '.mov', '.ts'))]
            if vid_files:
                best_file = max(vid_files, key=lambda x: x.get('bytes', 0))
                file_ids = str(best_file['id'])
            else:
                file_ids = 'all'

            SESSION.post(f"{rd_base}/torrents/selectFiles/{tid}", data={'files': file_ids}, headers=headers, timeout=12)

            # รอตรวจสอบสถานะลิงก์พร้อมเล่น (สูงสุด 5 วินาทีสำหรับไฟล์ Cached)
            for _ in range(5):
                xbmc.sleep(1000)
                info = SESSION.get(f"{rd_base}/torrents/info/{tid}", headers=headers, timeout=12).json()
                links = info.get('links', list())
                if links:
                    unres = SESSION.post(f"{rd_base}/unrestrict/link", data={'link': links[0]}, headers=headers, timeout=12).json()
                    if unres.get('download'):
                        return unres['download']
                if info.get('status') in ('downloading', 'queued', 'magnet_conversion'):
                    xbmcgui.Dialog().notification('Real-Debrid', 'Not cached yet - Trying next Debrid...', xbmcgui.NOTIFICATION_WARNING, 3000)
                    break
        except Exception as e:
            xbmcgui.Dialog().notification('Real-Debrid Error', str(e)[:60], xbmcgui.NOTIFICATION_ERROR, 5000)

    # 3. Premiumize Resolver
    if pm_key:
        try:
            r1 = SESSION.post("https://" + "www.premiumize.me/api/transfer/directdl", data={'apikey': pm_key, 'src': magnet_uri}, timeout=15).json()
            content = r1.get('content', list())
            if content:
                best = max(content, key=lambda x: x.get('size', 0))
                if best.get('link'):
                    return best['link']
        except Exception:
            pass

    # 4. TorBox Resolver
    if tb_key:
        try:
            headers = {'Authorization': f'Bearer {tb_key}'}
            r1 = SESSION.post("https://" + "api.torbox.app/v1/api/torrents/createtorrent", data={'magnet': magnet_uri}, headers=headers, timeout=12).json()
            tid = r1.get('data', {}).get('torrent_id')
            if tid:
                xbmc.sleep(1000)
                r2 = SESSION.get("https://" + "api.torbox.app/v1/api/torrents/requestdl", params={'token': tb_key, 'torrent_id': tid, 'file_id': 0, 'zip_link': 'false'}, timeout=12).json()
                if r2.get('data'):
                    return r2['data']
        except Exception:
            pass

    return None

def search_internal_streams(imdb_id, media_type='movie', season=1, episode=1, quality_filter='All'):
    if not imdb_id:
        return list()
    strem_type = 'series' if media_type == 'tv' else 'movie'
    strem_id = f"{imdb_id}:{season}:{episode}" if media_type == 'tv' else imdb_id

    sources = list()
    scrapers = (
        ("Torrentio", "https://" + f"torrentio.strem.fun/stream/{strem_type}/{strem_id}.json"),
        ("MediaFusion", "https://" + f"elfhosted.com{strem_type}/{strem_id}.json")
    )

    for provider, url in scrapers:
        try:
            res = SESSION.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=8).json()
            for s in res.get('streams', list()):
                title_raw = s.get('title') or s.get('name') or 'Unknown Stream'
                info_hash = s.get('infoHash', '')
                if not info_hash:
                    continue

                # กรองความละเอียดตามปุ่ม Quality Filter บนหน้าจอ
                low_t = title_raw.lower()
                if '1080p & 720p' in quality_filter and ('2160p' in low_t or '4k' in low_t):
                    continue
                elif '1080p Full HD' in quality_filter and '1080p' not in low_t:
                    continue
                elif '4K UHD' in quality_filter and ('2160p' not in low_t and '4k' not in low_t):
                    continue
                elif '720p HD' in quality_filter and '720p' not in low_t:
                    continue

                clean_line = title_raw.replace('\n', ' | ')[:95]
                magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={urllib.parse.quote(clean_line[:40])}"
                sources.append({
                    'label': f"[{provider}] {clean_line}",
                    'magnet': magnet
                })
        except Exception:
            continue

    return sources[:30]

class QRAuthDialog(xbmcgui.WindowDialog):
    def __init__(self, title, qr_target_url, display_url, pin_code):
        super().__init__()
        self.cancelled = False
        white_tex = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'white.png')
        qr_img_url = "https://" + "api." + "qrserver.com" + "/v1/create-qr-code/?size=320x320&data=" + urllib.parse.quote(qr_target_url)

        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, white_tex, colorDiffuse='CC000000'))
        self.addControl(xbmcgui.ControlImage(340, 80, 600, 560, white_tex, colorDiffuse='FF0F172A'))
        self.addControl(xbmcgui.ControlLabel(360, 100, 560, 40, f"[B]{title}[/B]", font='font14', textColor='FF10B981', alignment=2))
        self.addControl(xbmcgui.ControlLabel(360, 140, 560, 30, "Scan QR Code with your phone camera", font='font12', textColor='FFE2E8F0', alignment=2))
        self.addControl(xbmcgui.ControlImage(480, 180, 320, 320, qr_img_url))
        self.addControl(xbmcgui.ControlLabel(360, 515, 560, 30, f"URL: [COLOR cyan]{display_url}[/COLOR]", font='font12', textColor='FFFFFFFF', alignment=2))
        self.addControl(xbmcgui.ControlLabel(360, 545, 560, 35, f"CODE: [COLOR lime][B]{pin_code}[/B][/COLOR]", font='font14', textColor='FFFFFFFF', alignment=2))
        self.addControl(xbmcgui.ControlLabel(360, 595, 560, 30, "Press ESC or Back to Close", font='font12', textColor='FF94A3B8', alignment=2))
class RyuHomeWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.loaded = False
        self.row1_mode = 'catalog'
        self.quality_mode = ADDON.getSetting('quality_filter') or 'All (4K / 1080p / 720p)'

    def onInit(self):
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        self.update_quality_button()
        if not self.loaded:
            self.loaded = True
            self.load_default_rows()

    def update_quality_button(self):
        pass

    def populate_row(self, panel_id, label_id, endpoint, title, extra_params=None):
        if panel_id == 5001:
            self.row1_mode = 'catalog'
        self.getControl(label_id).setLabel(f"[B]{title}[/B]")
        items = fetch_tmdb(endpoint, extra_params)
        panel = self.getControl(panel_id)
        panel.reset()
        list_items = list()
        for item in items:
            m_title = item.get('title') or item.get('name') or 'Unknown'
            year = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            rating = str(round(float(item.get('vote_average', 0)), 1))
            plot = item.get('overview') or 'No overview available.'
            p_path = item.get('poster_path')
            b_path = item.get('backdrop_path')
            poster = ("https://" + "image." + "tmdb.org/t/p/w342" + p_path) if p_path else ''
            fanart = ("https://" + "image." + "tmdb.org/t/p/w1280" + b_path) if b_path else ''
            m_type = item.get('media_type') or ('tv' if 'tv' in endpoint else 'movie')

            li = xbmcgui.ListItem(label=m_title)
            li.setArt({'poster': poster, 'thumb': '', 'icon': poster, 'fanart': fanart})
            li.setProperty('subtitle', f"TMDb {rating}   |   {year}")
            li.setProperty('tmdb_id', str(item.get('id', '')))
            li.setProperty('media_type', m_type)
            li.setInfo('video', {'title': m_title, 'year': int(year) if year.isdigit() else 0, 'rating': float(rating), 'plot': plot})
            list_items.append(li)

        if list_items:
            panel.addItems(list_items)

    def load_default_rows(self):
        self.populate_row(5001, 103, 'trending/all/week', 'TRENDING NOW')
        self.populate_row(5002, 104, 'movie/popular', 'POPULAR MOVIES')
        self.populate_row(5003, 105, 'discover/tv', 'POPULAR ANIME & SERIES', {'with_genres': '16', 'with_original_language': 'ja', 'sort_by': 'popularity.desc'})
        self.setFocusId(5001)

    def load_authorize_cards(self):
        media_dir = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media')

        def make_card(srv_id, name, setting_id, img_name, is_key=False):
            val = ADDON.getSetting(setting_id).strip()
            status = "CONNECTED" if val else ("Enter API Key" if is_key else "Scan QR Code")
            icon_p = os.path.join(media_dir, img_name)
            li = xbmcgui.ListItem(label=name, label2=status)
            li.setProperty('srv_id', srv_id)
            li.setProperty('srv_name', name)
            li.setProperty('setting_id', setting_id)
            li.setProperty('plot', f"{name} — Status: {status}")
            li.setArt({'poster': icon_p, 'thumb': icon_p, 'icon': icon_p})
            return li

        # แถวที่ 1 (5001): Debrid Cloud Providers (4 การ์ดหลัก)
        row1_cards = [
            make_card('alldebrid', 'AllDebrid', 'ad_apikey', 'brand_alldebrid.png'),
            make_card('realdebrid', 'Real-Debrid', 'rd_token', 'brand_realdebrid.png'),
            make_card('torbox', 'TorBox', 'tb_apikey', 'brand_torbox.png'),
            make_card('premiumize', 'Premiumize', 'pm_apikey', 'brand_premiumize.png')
        ]

        # แถวที่ 2 (5002): Watchlist Sync & Buy Me a Coffee (4 การ์ดเห็นพร้อมกันทันที)
        row2_cards = [
            make_card('trakt', 'Trakt', 'trakt_token', 'brand_trakt.png'),
            make_card('simkl', 'Simkl', 'simkl_token', 'brand_simkl.png'),
            make_card('mdblist', 'MDBList', 'mdblist_apikey', 'brand_mdblist.png', is_key=True),
            make_card('coffee', 'Support RyuStream', 'coffee_supporter', 'brand_coffee.png')
        ]

        self.getControl(103).setLabel("Debrid Cloud Providers  •  Scan QR Code to Authorize")
        p1 = self.getControl(5001)
        p1.reset()
        p1.addItems(row1_cards)

        self.getControl(104).setLabel("Watchlist Sync (Trakt • Simkl • MDBList)  &  Support RyuStream")
        p2 = self.getControl(5002)
        p2.reset()
        p2.addItems(row2_cards)

        # ซ่อนแถวที่ 3 (5003) ชั่วคราวเพื่อให้โฟกัสอยู่แค่ 2 แถวนี้สะอาดตา
        self.getControl(105).setLabel("")
        self.getControl(5003).reset()
        self.setFocusId(5001)


    def handle_auth_click(self, srv_id, name, setting_id):
        try:
            if srv_id == 'support':
                coffee_url = "https://" + "buymeacoffee.com" + "/ryustream"
                qr_dlg = QRAuthDialog('Support RyuStream Developer', coffee_url, 'buymeacoffee.com', 'THANK YOU!')
                qr_dlg.show()
                while not qr_dlg.cancelled:
                    xbmc.sleep(500)
                qr_dlg.close()

            elif srv_id == 'alldebrid':
                url = "https://" + "api." + "alldebrid.com" + "/v4/pin/get?agent=RyuStream"
                res = SESSION.get(url, headers={'User-Agent': 'RyuStream/3.0.0'}, timeout=10).json()
                data = res.get('data', dict())
                pin = data.get('pin', '')
                check = data.get('check', '')
                user_url = data.get('user_url') or ("https://" + "alldebrid.com" + "/pin/?pin=" + pin)
                base_url = data.get('base_url') or ("https://" + "alldebrid.com" + "/pin")
                if not pin:
                    return
                qr_dlg = QRAuthDialog('Authorize AllDebrid', user_url, base_url, pin)
                qr_dlg.show()
                for _ in range(60):
                    if qr_dlg.cancelled:
                        break
                    xbmc.sleep(2000)
                    chk_url = "https://" + "api." + "alldebrid.com" + f"/v4/pin/check?agent=RyuStream&check={check}&pin={pin}"
                    chk = SESSION.get(chk_url, headers={'User-Agent': 'RyuStream/3.0.0'}, timeout=8).json()
                    if chk.get('data', dict()).get('activated'):
                        ADDON.setSetting('ad_apikey', chk.get('data', dict()).get('apikey', ''))
                        qr_dlg.close()
                        xbmcgui.Dialog().notification('AllDebrid', 'Connected via QR Code!', xbmcgui.NOTIFICATION_INFO, 4000)
                        self.load_authorize_cards()
                        return
                qr_dlg.close()

            elif srv_id == 'realdebrid':
                url = "https://" + "api." + "real-debrid.com" + f"/oauth/v2/device/code?client_id={RD_CLIENT_ID}&new_credentials=yes"
                res = SESSION.get(url, timeout=10).json()
                dev_code = res.get('device_code', '')
                user_code = res.get('user_code', '')
                ver_url = res.get('verification_url') or ("https://" + "real-debrid.com" + "/device")
                direct_url = res.get('direct_verification_url') or ver_url
                if not dev_code:
                    return
                qr_dlg = QRAuthDialog('Authorize Real-Debrid', direct_url, ver_url, user_code)
                qr_dlg.show()
                for _ in range(60):
                    if qr_dlg.cancelled:
                        break
                    xbmc.sleep(2500)
                    cred_url = "https://" + "api." + "real-debrid.com" + f"/oauth/v2/device/credentials?client_id={RD_CLIENT_ID}&code={dev_code}"
                    cred_res = SESSION.get(cred_url, timeout=8)
                    if cred_res.status_code == 200:
                        creds = cred_res.json()
                        tok_url = "https://" + "api." + "real-debrid.com" + "/oauth/v2/token"
                        tok_data = {
                            'client_id': creds['client_id'],
                            'client_secret': creds['client_secret'],
                            'code': dev_code,
                            'grant_type': 'http://' + 'oauth.net/grant_type/device/1.0'
                        }
                        tok_res = SESSION.post(tok_url, data=tok_data, timeout=8).json()
                        if tok_res.get('access_token'):
                            ADDON.setSetting('rd_apikey', tok_res['access_token'])
                            qr_dlg.close()
                            xbmcgui.Dialog().notification('Real-Debrid', 'Connected via QR Code!', xbmcgui.NOTIFICATION_INFO, 4000)
                            self.load_authorize_cards()
                            return
                qr_dlg.close()

            elif srv_id == 'premiumize':
                url = "https://" + "www.premiumize.me/token"
                res = SESSION.post(url, data={'client_id': PM_CLIENT_ID, 'response_type': 'device_code'}, timeout=10).json()
                dev_code = res.get('device_code', '')
                user_code = res.get('user_code', '')
                ver_url = res.get('verification_uri') or ("https://" + "www.premiumize.me/device")
                if not dev_code:
                    return
                qr_dlg = QRAuthDialog('Authorize Premiumize', f"{ver_url}?user_code={user_code}", ver_url, user_code)
                qr_dlg.show()
                for _ in range(60):
                    if qr_dlg.cancelled:
                        break
                    xbmc.sleep(2500)
                    tok_res = SESSION.post(url, data={'client_id': PM_CLIENT_ID, 'code': dev_code, 'grant_type': 'device_code'}, timeout=8).json()
                    if tok_res.get('access_token'):
                        ADDON.setSetting('pm_apikey', tok_res['access_token'])
                        qr_dlg.close()
                        xbmcgui.Dialog().notification('Premiumize', 'Connected via QR Code!', xbmcgui.NOTIFICATION_INFO, 4000)
                        self.load_authorize_cards()
                        return
                qr_dlg.close()

            elif srv_id == 'trakt':
                t_headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': TRAKT_CLIENT_ID}
                url = "https://" + "api.trakt.tv/oauth/device/code"
                r = SESSION.post(url, json={'client_id': TRAKT_CLIENT_ID}, headers=t_headers, timeout=10)
                if not r.ok:
                    return
                res = r.json()
                dev_code = res.get('device_code', '')
                user_code = res.get('user_code', '')
                ver_url = res.get('verification_url') or ("https://" + "trakt.tv/activate")
                if not dev_code:
                    return
                qr_dlg = QRAuthDialog('Authorize Trakt.tv', f"{ver_url}?code={user_code}", ver_url, user_code)
                qr_dlg.show()
                for _ in range(60):
                    if qr_dlg.cancelled:
                        break
                    xbmc.sleep(3000)
                    tok_url = "https://" + "api.trakt.tv/oauth/device/token"
                    tok_res = SESSION.post(tok_url, json={'code': dev_code, 'client_id': TRAKT_CLIENT_ID}, headers=t_headers, timeout=8)
                    if tok_res.status_code == 200:
                        ADDON.setSetting('trakt_token', tok_res.json().get('access_token', ''))
                        qr_dlg.close()
                        xbmcgui.Dialog().notification('Trakt.tv', 'Connected via QR Code!', xbmcgui.NOTIFICATION_INFO, 4000)
                        self.load_authorize_cards()
                        return
                qr_dlg.close()

            elif srv_id == 'simkl':
                url = "https://" + "api." + "simkl.com" + f"/oauth/pin?client_id={SIMKL_CLIENT_ID}"
                res = SESSION.get(url, timeout=10).json()
                user_code = res.get('user_code', '')
                ver_url = res.get('verification_url') or ("https://" + "simkl.com" + "/pin")
                if not user_code:
                    return
                qr_dlg = QRAuthDialog('Authorize Simkl', f"{ver_url}/{user_code}", ver_url, user_code)
                qr_dlg.show()
                for _ in range(60):
                    if qr_dlg.cancelled:
                        break
                    xbmc.sleep(3000)
                    chk_url = "https://" + "api." + "simkl.com" + f"/oauth/pin/{user_code}?client_id={SIMKL_CLIENT_ID}"
                    chk = SESSION.get(chk_url, timeout=8).json()
                    if chk.get('result') == 'OK' and chk.get('access_token'):
                        ADDON.setSetting('simkl_token', chk['access_token'])
                        qr_dlg.close()
                        xbmcgui.Dialog().notification('Simkl', 'Connected via QR Code!', xbmcgui.NOTIFICATION_INFO, 4000)
                        self.load_authorize_cards()
                        return
                qr_dlg.close()

            elif srv_id in ('torbox', 'mdblist'):
                web_url = "https://" + ("torbox.app/settings" if srv_id == 'torbox' else "mdblist.com")
                qr_dlg = QRAuthDialog(f"{name} API Key", web_url, web_url, "SCAN QR -> COPY API KEY")
                qr_dlg.show()
                while not qr_dlg.cancelled:
                    xbmc.sleep(500)
                qr_dlg.close()
                current = ADDON.getSetting(setting_id)
                kb = xbmc.Keyboard(current, f"Paste {name} API Key")
                kb.doModal()
                if kb.isConfirmed():
                    ADDON.setSetting(setting_id, kb.getText().strip())
                    xbmcgui.Dialog().notification(name, 'Saved Successfully!', xbmcgui.NOTIFICATION_INFO, 3000)
                    self.load_authorize_cards()

        except Exception as e:
            xbmcgui.Dialog().notification(f'{name} Error', str(e)[:60], xbmcgui.NOTIFICATION_ERROR, 5000)

    def play_media_item(self, li):
        m_title = li.getLabel()
        tmdb_id = li.getProperty('tmdb_id')
        m_type = li.getProperty('media_type') or 'movie'

        # ตรวจสอบว่าเชื่อมต่อ Debrid อย่างน้อย 1 บริการหรือยัง
        has_debrid = any(ADDON.getSetting(k).strip() for k in ('ad_apikey', 'rd_apikey', 'pm_apikey', 'tb_apikey'))
        if not has_debrid:
            xbmcgui.Dialog().ok('Debrid Required', 'Please authorize AllDebrid, Real-Debrid, Premiumize, or TorBox in "Debrid Cloud (Authorize)" first.')
            self.load_authorize_cards()
            return

        season = 1
        episode = 1
        if m_type == 'tv':
            s_in = xbmcgui.Dialog().numeric(0, f'{m_title} - Season Number', '1')
            if not s_in:
                return
            e_in = xbmcgui.Dialog().numeric(0, f'{m_title} - Episode Number', '1')
            if not e_in:
                return
            season = int(s_in)
            episode = int(e_in)

        pDlg = xbmcgui.DialogProgress()
        pDlg.create('RyuStream Internal Scraper', f'Searching streams for {m_title}...')
        pDlg.update(30)
        imdb_id = get_imdb_id(tmdb_id, m_type)
        pDlg.update(60, f'Querying Torrentio & MediaFusion ({self.quality_mode.split(" ")[0][0]})...')
        streams = search_internal_streams(imdb_id, m_type, season, episode, self.quality_mode)
        pDlg.close()

        if not streams:
            xbmcgui.Dialog().notification('No Streams Found', 'Try changing Quality Filter to "All"', xbmcgui.NOTIFICATION_WARNING, 4000)
            return

        labels = [s['label'] for s in streams]
        sel = xbmcgui.Dialog().select(f'Select Stream ({len(streams)} found)', labels)
        if sel < 0:
            return

        pDlg.create('RyuStream Debrid Engine', 'Resolving high-speed Debrid stream link...')
        pDlg.update(50)
        stream_url = resolve_debrid_magnet(streams[sel]['magnet'])
        pDlg.close()

        if not stream_url:
            xbmcgui.Dialog().notification('Debrid Error', 'Could not resolve stream link (Check Debrid account)', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        play_li = xbmcgui.ListItem(label=m_title, path=stream_url)
        play_li.setInfo('video', {'title': m_title})
        xbmc.Player().play(stream_url, play_li)

    def select_quality_filter(self):
        options = (
            'All (4K / 1080p / 720p)',
            '1080p & 720p Only (No 4K - Low RAM TV)',
            '1080p Full HD Only',
            '4K UHD / HDR Only',
            '720p HD Only (Fastest)'
        )
        idx = xbmcgui.Dialog().select('Select Preferred Video Quality', list(options))
        if idx >= 0:
            self.quality_mode = options[idx]
            ADDON.setSetting('quality_filter', self.quality_mode)
            self.update_quality_button()
            xbmcgui.Dialog().notification('Quality Filter', self.quality_mode, xbmcgui.NOTIFICATION_INFO, 3000)

    def open_search_dialog(self):
        kb = xbmc.Keyboard('', 'Search Movies, TV Shows & Anime')
        kb.doModal()
        if not kb.isConfirmed():
            return
        query = kb.getText().strip()
        if not query:
            return
        self.populate_row(5001, 103, 'search/multi', f'Search Results: {query}', {'query': query})
        self.setFocusId(5001)

    def open_discover_menu(self):
        cats = ['Discover Movies', 'Discover TV Series', 'Discover Anime']
        c_idx = xbmcgui.Dialog().select('RyuStream Discover', cats)
        if c_idx < 0:
            return
        genres = [
            ('Action & Adventure', '28' if c_idx == 0 else '10759'),
            ('Comedy', '35'),
            ('Drama', '18'),
            ('Sci-Fi & Fantasy', '878' if c_idx == 0 else '10765'),
            ('Horror & Mystery', '27' if c_idx == 0 else '9648'),
            ('Animation', '16'),
            ('Romance', '10749')
        ]
        g_idx = xbmcgui.Dialog().select('Select Genre', [g for g in genres])
        if g_idx < 0:
            return
        sorts = [
            ('Most Popular', 'popularity.desc'),
            ('Top Rated', 'vote_average.desc'),
            ('Newest Releases', 'primary_release_date.desc' if c_idx == 0 else 'first_air_date.desc')
        ]
        s_idx = xbmcgui.Dialog().select('Sort By', [s for s in sorts])
        if s_idx < 0:
            return
        ep = 'discover/movie' if c_idx == 0 else 'discover/tv'
        extra = {'with_genres': genres[g_idx], 'sort_by': sorts[s_idx], 'vote_count.gte': 40}
        if c_idx == 2:
            extra['with_genres'] = f"16,{genres[g_idx]}" if genres[g_idx] != '16' else '16'
            extra['with_original_language'] = 'ja'
        self.populate_row(5001, 103, ep, f"{cats[c_idx]} • {genres[g_idx]} ({sorts[s_idx]})", extra)
        self.setFocusId(5001)

    def open_cloud_lists_menu(self):
        if not hasattr(self, '_lists_cache'):
            self._lists_cache = dict()

        trakt_tok = ADDON.getSetting('trakt_token').strip()
        simkl_tok = ADDON.getSetting('simkl_token').strip()
        mdb_key = ADDON.getSetting('mdblist_apikey').strip()

        choices, actions = list(), list()
        if trakt_tok:
            choices.extend(['[Trakt] Watchlist (Movies)', '[Trakt] Watchlist (TV Shows)', '[Trakt] My Custom Lists'])
            actions.extend([('trakt', 'w_movie'), ('trakt', 'w_tv'), ('trakt', 'custom')])
        if simkl_tok:
            choices.extend(['[Simkl] Plan to Watch (Anime)', '[Simkl] Plan to Watch (TV Shows)', '[Simkl] Plan to Watch (Movies)', '[Simkl] Currently Watching'])
            actions.extend([('simkl', 'anime'), ('simkl', 'shows'), ('simkl', 'movies'), ('simkl', 'watching')])
        if mdb_key:
            choices.append('[MDBList] Watchlist & Custom Lists')
            actions.append(('mdblist', 'all'))

        if not choices:
            xbmcgui.Dialog().notification('My Lists', 'Connect Trakt, Simkl, or MDBList in Debrid Cloud first!', xbmcgui.NOTIFICATION_WARNING, 4000)
            return

        choices.append('[Refresh & Clear Cache]')
        actions.append(('refresh', 'clear'))

        idx = xbmcgui.Dialog().select('My Cloud Lists (Trakt • Simkl • MDBList)', choices)
        if idx < 0:
            return
        prov, mode = actions[idx]
        if prov == 'refresh':
            self._lists_cache.clear()
            xbmcgui.Dialog().notification('My Lists', 'Cache cleared!', xbmcgui.NOTIFICATION_INFO, 2000)
            return

        cache_key = f"{prov}_{mode}"
        if cache_key in self._lists_cache and mode not in ('custom', 'all'):
            items, lbl = self._lists_cache[cache_key]
            self.getControl(103).setLabel(lbl)
            p = self.getControl(5001)
            p.reset()
            p.addItems(items)
            self.setFocusId(5001)
            return

        s = chr(47)
        raw_entries = list()
        header_lbl = choices[idx]
        pDlg = xbmcgui.DialogProgress()
        pDlg.create('RyuStream Cloud Lists', f'Loading {header_lbl}...')
        pDlg.update(35)

        try:
            if prov == 'trakt':
                t_base = "https:" + s + s + "api." + "trakt.tv"
                cid = ADDON.getSetting('trakt_client_id').strip() or '0183a05ad97098d87287fe46da4ae286f434f32e8e951caad4cc147c947d79a3'
                hdr = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': cid, 'Authorization': f'Bearer {trakt_tok}'}
                if mode == 'w_movie':
                    for x in requests.get(f"{t_base}/sync/watchlist/movies", headers=hdr, timeout=8).json():
                        m = x.get('movie', dict())
                        if m.get('ids', {}).get('tmdb'):
                            raw_entries.append((m['ids']['tmdb'], 'movie', m.get('title', '')))
                elif mode == 'w_tv':
                    for x in requests.get(f"{t_base}/sync/watchlist/shows", headers=hdr, timeout=8).json():
                        sh = x.get('show', dict())
                        if sh.get('ids', {}).get('tmdb'):
                            raw_entries.append((sh['ids']['tmdb'], 'tv', sh.get('title', '')))
                elif mode == 'custom':
                    pDlg.close()
                    ulists = requests.get(f"{t_base}/users/me/lists", headers=hdr, timeout=8).json()
                    if not ulists:
                        xbmcgui.Dialog().notification('Trakt', 'No custom lists found', xbmcgui.NOTIFICATION_INFO, 3000)
                        return
                    li_idx = xbmcgui.Dialog().select('Select Trakt List', [u.get('name', 'List') for u in ulists])
                    if li_idx < 0:
                        return
                    slug = ulists[li_idx].get('ids', {}).get('slug')
                    header_lbl = f"Trakt: {ulists[li_idx].get('name')}"
                    pDlg.create('RyuStream Cloud Lists', f'Loading {header_lbl}...')
                    for x in requests.get(f"{t_base}/users/me/lists/{slug}/items", headers=hdr, timeout=8).json():
                        if 'movie' in x and x['movie'].get('ids', {}).get('tmdb'):
                            raw_entries.append((x['movie']['ids']['tmdb'], 'movie', x['movie'].get('title', '')))
                        elif 'show' in x and x['show'].get('ids', {}).get('tmdb'):
                            raw_entries.append((x['show']['ids']['tmdb'], 'tv', x['show'].get('title', '')))

            elif prov == 'simkl':
                s_base = "https:" + s + s + "api." + "simkl.com"
                scid = ADDON.getSetting('simkl_client_id').strip() or '39e8640b6f1a60aaf60f3f3313475e830517badab8048a4e52ff2d10deb2b9b0'
                shdr = {'Authorization': f'Bearer {simkl_tok}', 'simkl-api-key': scid}
                ep_map = {
                    'anime': ('/sync/all-items/anime/plantowatch', 'anime', 'tv'),
                    'shows': ('/sync/all-items/shows/plantowatch', 'shows', 'tv'),
                    'movies': ('/sync/all-items/movies/plantowatch', 'movies', 'movie'),
                    'watching': ('/sync/all-items/watching', 'shows', 'tv')
                }
                ep, kname, mt = ep_map[mode]
                data = requests.get(f"{s_base}{ep}", headers=shdr, timeout=8).json()
                for x in (data.get(kname, list()) if isinstance(data, dict) else list()):
                    obj = x.get('show') or x.get('movie') or dict()
                    if obj.get('ids', {}).get('tmdb'):
                        raw_entries.append((obj['ids']['tmdb'], mt, obj.get('title', '')))

            elif prov == 'mdblist':
                pDlg.close()
                m_base = "https:" + s + s + "mdblist.com" + s + "api"
                ulists = requests.get(f"{m_base}/lists/user", params={'apikey': mdb_key}, timeout=8).json()
                if not isinstance(ulists, list) or not ulists:
                    xbmcgui.Dialog().notification('MDBList', 'No lists found on MDBList', xbmcgui.NOTIFICATION_INFO, 3000)
                    return
                li_idx = xbmcgui.Dialog().select('Select MDBList Watchlist / List', [f"{u.get('name')} ({u.get('items', 0)})" for u in ulists])
                if li_idx < 0:
                    return
                lid = ulists[li_idx].get('id')
                header_lbl = f"MDBList: {ulists[li_idx].get('name')}"
                pDlg.create('RyuStream Cloud Lists', f'Loading {header_lbl}...')
                ritems = requests.get(f"{m_base}/lists/{lid}/items", params={'apikey': mdb_key}, timeout=8).json()
                comb = (ritems.get('movies', list()) if isinstance(ritems, dict) else list()) + (ritems.get('shows', list()) if isinstance(ritems, dict) else list())
                for it in comb:
                    tid = it.get('id') or it.get('tmdb_id')
                    mt = 'tv' if it.get('mediatype') == 'show' else 'movie'
                    if tid:
                        raw_entries.append((tid, mt, it.get('title', '')))

            pDlg.update(70, 'Loading Posters in Parallel...')
            built_cards = list()

            def build_card(entry):
                tid, mt, ftitle = entry
                info = fetch_tmdb(f"{mt}/{tid}")
                if not info:
                    return None
                title = info.get('title') or info.get('name') or ftitle
                poster = f"https:{s}{s}image.tmdb.org{s}t{s}p{s}w500{info['poster_path']}" if info.get('poster_path') else ''
                fanart = f"https:{s}{s}image.tmdb.org{s}t{s}p{s}w1280{info['backdrop_path']}" if info.get('backdrop_path') else ''
                li = xbmcgui.ListItem(label=title)
                li.setProperty('tmdb_id', str(tid))
                li.setProperty('media_type', mt)
                li.setProperty('year', str((info.get('release_date') or info.get('first_air_date') or '')[:4]))
                li.setProperty('plot', info.get('overview', ''))
                li.setArt({'poster': poster, 'thumb': poster, 'fanart': fanart})
                return li

            with ThreadPoolExecutor(max_workers=6) as ex:
                for c in ex.map(build_card, raw_entries[:30]):
                    if c:
                        built_cards.append(c)

            pDlg.close()
            if built_cards:
                self._lists_cache[cache_key] = (built_cards, header_lbl)
                self.getControl(103).setLabel(header_lbl)
                p = self.getControl(5001)
                p.reset()
                p.addItems(built_cards)
                self.setFocusId(5001)
            else:
                xbmcgui.Dialog().notification('My Lists', 'This list is empty', xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            pDlg.close()
            xbmcgui.Dialog().notification('Lists Error', str(e)[:55], xbmcgui.NOTIFICATION_ERROR, 3500)

    def select_scraper_mode(self):
        modes = ['Internal (8 POV-Style Scrapers)', 'External (CocoScrapers Module)', 'Hybrid (Internal + External)']
        idx = xbmcgui.Dialog().select('Select Scraper Engine', modes)
        if idx >= 0:
            self.scraper_mode = modes[idx]
            ADDON.setSetting('scraper_mode', self.scraper_mode)
            xbmcgui.Dialog().notification('Scraper Engine', self.scraper_mode, xbmcgui.NOTIFICATION_INFO, 2500)

    def open_more_menu(self):
        q_cur = getattr(self, 'quality_mode', ADDON.getSetting('quality_filter') or 'All').split(' ')
        s_cur = getattr(self, 'scraper_mode', ADDON.getSetting('scraper_mode') or 'Internal').split(' ')
        tiles = [
            ('Discover', 'Movies • Series • Anime', 'tile_discover.png', 'discover'),
            ('My Lists', 'Trakt • Simkl • MDBList', 'tile_lists.png', 'lists'),
            ('Anime Hub', 'Trending Japanese Anime', 'tile_anime.png', 'anime'),
            (f'Scraper: {s_cur}', 'Switch Internal / External', 'tile_scraper.png', 'scraper'),
            (f'Quality: {q_cur}', 'Filter 4K / 1080p / 720p', 'tile_quality.png', 'quality'),
            ('Debrid & Accounts', 'QR Code Auth & Cloud', 'tile_cloud.png', 'debrid')
        ]
        built = list()
        for title, sub, icon_fn, act in tiles:
            icon_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', icon_fn)
            li = xbmcgui.ListItem(label=title, label2=sub)
            li.setProperty('more_action', act)
            li.setProperty('plot', f"{title} — {sub}")
            li.setArt({'poster': icon_path, 'thumb': icon_path, 'icon': icon_path})
            built.append(li)

        self.getControl(103).setLabel("More  •  Tools, Lists & Preferences")
        panel = self.getControl(5001)
        panel.reset()
        panel.addItems(built)
        self.setFocusId(5001)

    def handle_more_tile(self, act):
        if act == 'discover':
            self.open_discover_menu()
        elif act == 'lists':
            self.open_cloud_lists_menu()
        elif act == 'anime':
            self.populate_row(5001, 103, 'discover/tv', 'Anime Hub • Trending Japanese Anime', {'with_genres': '16', 'with_original_language': 'ja', 'sort_by': 'popularity.desc'})
            self.setFocusId(5001)
        elif act == 'scraper':
            self.select_scraper_mode()
            self.open_more_menu()
        elif act == 'quality':
            self.select_quality_filter()
            self.open_more_menu()
        elif act == 'debrid':
            self.load_authorize_cards()
            self.setFocusId(5001)

    def onClick(self, controlId):
        try:
            if controlId == 901:
                self.load_default_rows()
                self.setFocusId(5001)
            elif controlId == 904:
                self.open_search_dialog()
            elif controlId == 902:
                self.load_authorize_cards()
                self.setFocusId(5001)
            elif controlId == 910:
                self.open_more_menu()
            elif controlId == 909:
                self.close()
            elif controlId in (5001, 5002, 5003):
                panel = self.getControl(controlId)
                li = panel.getSelectedItem()
                if not li:
                    return
                more_act = li.getProperty('more_action')
                srv_id = li.getProperty('srv_id')
                if more_act:
                    self.handle_more_tile(more_act)
                elif srv_id:
                    self.handle_auth_click(srv_id, li.getProperty('srv_name') or li.getLabel(), li.getProperty('setting_id'))
                else:
                    self.play_media_item(li)
        except Exception as e:
            xbmcgui.Dialog().notification('Menu Error', str(e)[:60], xbmcgui.NOTIFICATION_ERROR, 4000)

    def onAction(self, action):
        if action.getId() in (10, 13, 92, 110, 122) or action.getButtonCode() in (27, 61467, 61448):
            self.close()


def router():
    try:
        handle = int(sys.argv)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    except Exception:
        pass
    win = RyuHomeWindow('ryu_home.xml', ADDON_PATH, 'Default', '1080i')
    win.doModal()
    del win


if __name__ == '__main__':
    router()
